import os
from ska_serverless.config import read_config

read_config('config.ini')

import ska_serverless.binary_app as ba

ba.aoflagger("ngc5921.demo.ms")

ba.wsclean("ngc5921.demo.ms", [1280,1280], "8arcsec", 0.8, 10000, 0.01, True)
